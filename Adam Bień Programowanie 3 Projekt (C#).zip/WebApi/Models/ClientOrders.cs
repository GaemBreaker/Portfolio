﻿namespace WebApi.Models
{
    public class ClientOrders
    {
        public int ID { get; set; }

        public int OrderedAmount { get; set; }

        public string? OrdererName { get; set; }

        public string? OrdererSurename { get; set; }
        
        public string? OrderCity { get; set; }
    }
}
