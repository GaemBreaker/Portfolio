﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace WebApi.Models
{
    public class WarehouseContext : DbContext
    {
        public WarehouseContext(DbContextOptions<WarehouseContext> options) : base(options)
        {
        }

        public DbSet<Warehouse> Goods { get; set; }

        public DbSet<ClientOrders> ClientOrders { get; set; }
    }
}
