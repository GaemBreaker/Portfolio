﻿namespace WebApi.Models
{
    public class Warehouse
    {
        public int ID { get; set; }

        public string? WareName { get; set; }

        public int SerialNumber { get; set; }

        public string? LetterPosition { get; set; }

        public int NumberPosition { get; set; }

        public string? DockerName { get; set; }

        public string? DockerSurename { get; set; }
    }
}
