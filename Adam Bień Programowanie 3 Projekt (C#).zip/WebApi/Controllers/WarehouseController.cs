﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApi.Models;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WarehouseController : ControllerBase
    {
        private readonly WarehouseContext _dbContext;

        public WarehouseController(WarehouseContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet("Tables")]
        public ActionResult GetTables()
        {
            var data = from Warehouse in _dbContext.Goods
                                  join Orders in _dbContext.ClientOrders on Warehouse.ID equals Orders.ID
                                  select new Tables
                                  {
                                      ID = Warehouse.ID,
                                      WareName = Warehouse.WareName,
                                      SerialNumber = Warehouse.SerialNumber,
                                      LetterPosition = Warehouse.LetterPosition,
                                      NumberPosition = Warehouse.NumberPosition,
                                      DockerName = Warehouse.DockerName,
                                      DockerSurename = Warehouse.DockerSurename,
                                      OrderedAmount = Orders.OrderedAmount,
                                      OrdererName = Orders.OrdererName,
                                      OrdererSurename = Orders.OrdererSurename,
                                      OrderCity = Orders.OrderCity,
                                  };

            var result = data.ToList();
            
            if (!result.Any())
            {
                return NotFound();
            }
            return Ok(result);
        }

        [HttpGet("Warehouse")]
        public async Task<ActionResult<IEnumerable<Warehouse>>> GetGoods()
        {
            if (_dbContext.Goods == null)
            {
                return NotFound();
            }
            return await _dbContext.Goods.ToListAsync();
        }

        [HttpGet("Warehouse/{id}")]
        public async Task<ActionResult<Warehouse>> GetGood(int id)
        {
            if (_dbContext.Goods == null)
            {
                return NotFound();
            }
            var good = await _dbContext.Goods.FindAsync(id);
            if (good == null)
            {
                return NotFound();
            }
            return good;
        }

        [HttpPost("Warehouse")]
        public async Task<ActionResult<Warehouse>> PostGoods(Warehouse warehouse)
        {
            _dbContext.Goods.Add(warehouse);
            await _dbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetGood), new { id = warehouse.ID }, warehouse);
        }

        [HttpPut("Warehouse")]
        public async Task<IActionResult> PutGoods(int id, Warehouse warehouse)
        {
            if (id != warehouse.ID)
            {
                return BadRequest();
            }
            _dbContext.Entry(warehouse).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch(DbUpdateConcurrencyException)
            {
                if (!GoodAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Ok();
        }

        private bool GoodAvailable(int id)
        {
            return (_dbContext.Goods?.Any(x => x.ID == id)).GetValueOrDefault();
        }

        [HttpDelete("Warehouse/{id}")]
        public async Task<IActionResult> DeleteGoods(int id)
        {
            if (_dbContext.Goods == null)
            {
                return NotFound();
            }

            var good = await _dbContext.Goods.FindAsync(id);
            if (good == null)
            {
                return NotFound();
            }

            _dbContext.Goods.Remove(good);

            await _dbContext.SaveChangesAsync();

            return Ok();
        }

        [HttpGet("ClientOrders")]
        public async Task<ActionResult<IEnumerable<ClientOrders>>> GetOrders()
        {
            if (_dbContext.ClientOrders == null)
            {
                return NotFound();
            }
            return await _dbContext.ClientOrders.ToListAsync();
        }

        [HttpGet("ClientOrders/{id}")]
        public async Task<ActionResult<ClientOrders>> GetOrder(int id)
        {
            if (_dbContext.ClientOrders == null)
            {
                return NotFound();
            }
            var good = await _dbContext.ClientOrders.FindAsync(id);
            if (good == null)
            {
                return NotFound();
            }
            return good;
        }

        [HttpPost("ClientOrders")]
        public async Task<ActionResult<ClientOrders>> PostOrders(ClientOrders orders)
        {
            _dbContext.ClientOrders.Add(orders);
            await _dbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetOrder), new { id = orders.ID }, orders);
        }

        [HttpPut("ClientOrders")]
        public async Task<IActionResult> PutOrders(int id, [FromBody]ClientOrders orders)
        {
            if (id != orders.ID)
            {
                return BadRequest();
            }
            _dbContext.Entry(orders).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrderAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Ok();
        }

        private bool OrderAvailable(int id)
        {
            return (_dbContext.ClientOrders?.Any(x => x.ID == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOrders(int id)
        {
            if (_dbContext.ClientOrders == null)
            {
                return NotFound();
            }

            var good = await _dbContext.ClientOrders.FindAsync(id);
            if (good == null)
            {
                return NotFound();
            }

            _dbContext.ClientOrders.Remove(good);

            await _dbContext.SaveChangesAsync();

            return Ok();
        }
    }
}
