﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApi.Migrations
{
    /// <inheritdoc />
    public partial class Second : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsActive",
                table: "Goods");

            migrationBuilder.DropColumn(
                name: "OrderCity",
                table: "Goods");

            migrationBuilder.DropColumn(
                name: "OrdererName",
                table: "Goods");

            migrationBuilder.DropColumn(
                name: "OrdererSurename",
                table: "Goods");

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WareNameOrder = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OrderedAmount = table.Column<int>(type: "int", nullable: false),
                    OrdererName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OrdererSurename = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OrderCity = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.ID);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.AddColumn<int>(
                name: "IsActive",
                table: "Goods",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "OrderCity",
                table: "Goods",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "OrdererName",
                table: "Goods",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "OrdererSurename",
                table: "Goods",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
