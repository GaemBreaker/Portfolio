﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programowanie3Projekt.Models
{
    internal class ClientOrders
    {
        public int ID { get; set; }

        public int OrderedAmount { get; set; }

        public string OrdererName { get; set; }

        public string OrdererSurename { get; set; }

        public string OrderCity { get; set; }
    }
}
