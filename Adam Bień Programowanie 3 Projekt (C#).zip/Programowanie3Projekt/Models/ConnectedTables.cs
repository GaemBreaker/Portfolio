﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programowanie3Projekt.Models
{
    internal class ConnectedTables
    {
        public int ID { get; set; }

        public string WareName { get; set; }

        public int SerialNumber { get; set; }

        public string LetterPosition { get; set; }

        public int NumberPosition { get; set; }

        public string DockerName { get; set; }

        public string DockerSurename { get; set; }

        public int OrderedAmount { get; set; }

        public string OrdererName { get; set; }

        public string OrdererSurename { get; set; }

        public string OrderCity { get; set; }
    }
}
