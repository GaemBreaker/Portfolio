﻿using Newtonsoft.Json;
using Programowanie3Projekt.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Programowanie3Projekt
{
    /// <summary>
    /// Interaction logic for Goods.xaml
    /// </summary>
    public partial class Goods : Window
    {
        HttpClient client = new HttpClient();

        public Goods()
        {
            client.BaseAddress = new Uri("http://localhost:5090/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
                );
            InitializeComponent();
        }

        private void btnLoadWarehouse_Click(object sender, RoutedEventArgs e)
        {
            this.GetWarehouse();
        }

        private async void GetWarehouse()
        {
            lblMessage.Content = "";
            var response = await client.GetStringAsync("warehouse/warehouse");
            var warehouse = JsonConvert.DeserializeObject<List<Warehouse>>(response);
            dataGridWarehouse.DataContext = warehouse;
        }

        private void btnSaveGood_Click(object sender, RoutedEventArgs e)
        {
            var warehouse = new Warehouse()
            {
                ID = Convert.ToInt32(txtId.Text),
                WareName = txtWareName.Text,
                SerialNumber = Convert.ToInt32(txtSerialNumber.Text),
                LetterPosition = txtLetterPosition.Text,
                NumberPosition = Convert.ToInt32(txtNumberPosition.Text),
                DockerName = txtDockerName.Text,
                DockerSurename = txtDockerSurename.Text,
            };

            if (warehouse.ID == 0)
            {
                this.SaveWarehouse(warehouse);
                lblMessage.Content = "Dodano wpis do magazynu";
            }
            else
            {
                this.UpdateWarehouse(warehouse);
                lblMessage.Content = "Zaktualizowano spis magazynu";
            }

            txtId.Text = 0.ToString();
            txtWareName.Text = "";
            txtSerialNumber.Text = 0.ToString();
            txtLetterPosition.Text = "";
            txtNumberPosition.Text = 0.ToString();
            txtDockerName.Text = "";
            txtDockerSurename.Text = "";


        }

        void btnEditGood(object sender, RoutedEventArgs e)
        {
            Warehouse warehouse = ((FrameworkElement)sender).DataContext as Warehouse;
            txtId.Text = warehouse.ID.ToString();
            txtWareName.Text = warehouse.WareName;
            txtSerialNumber.Text = warehouse.SerialNumber.ToString();
            txtLetterPosition.Text = warehouse.LetterPosition;
            txtNumberPosition.Text = warehouse.NumberPosition.ToString();
            txtDockerName.Text = warehouse.DockerName;
            txtDockerSurename.Text = warehouse.DockerSurename;
        }

        private async void SaveWarehouse(Warehouse warehouse)
        {
            await client.PostAsJsonAsync("warehouse/warehouse", warehouse);
        }

        private async void UpdateWarehouse(Warehouse warehouse)
        {
            await client.PutAsJsonAsync("warehouse/warehouse/" + warehouse.ID, warehouse);
        }
    }
}
