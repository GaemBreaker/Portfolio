﻿using Newtonsoft.Json;
using Programowanie3Projekt.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Programowanie3Projekt
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        HttpClient client = new HttpClient();

        public MainWindow()
        {
            client.BaseAddress = new Uri("http://localhost:5090/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
                );
            InitializeComponent();
        }

        private void btnLoadWarehouse_Click(object sender, RoutedEventArgs e)
        {
            this.GetWarehouse();
        }

        private async void GetWarehouse()
        {
            lblMessage.Content = "";

            try
            {
                var response = await client.GetStringAsync("warehouse/tables");
                var connectedTables = JsonConvert.DeserializeObject<List<ConnectedTables>>(response);
                dataGridWarehouse.DataContext = connectedTables;
            }
            catch (HttpRequestException ex)
            {
                lblMessage.Content = "Błąd podczas pobierania danych z serwera: " + ex.Message;
            }
        }

        private async void DeleteWarehouse(int id)
        {
            await client.DeleteAsync("warehouse/warehouse/"+ id);
            await client.DeleteAsync("warehouse/clientorders/"+ id);
        }

        void btnDeleteGood(object sender, RoutedEventArgs e)
        {
            ConnectedTables connectedTables = ((FrameworkElement)sender).DataContext as ConnectedTables;
            this.DeleteWarehouse(connectedTables.ID);
        }

        private void btnEditGoods_Click(object sender, RoutedEventArgs e)
        {
            Goods goods = new Goods();
            goods.Owner = this;
            goods.ShowDialog();
        }

        private void btnEditOrders_Click(object sender, RoutedEventArgs e)
        {
            Orders orders = new Orders();
            orders.Owner = this;
            orders.ShowDialog();
        }

        private void btnAddRecord_Click(object sender, RoutedEventArgs e)
        {
            AddOrder addOrder = new AddOrder();
            addOrder.Owner = this;
            addOrder.ShowDialog();
        }
    }
}
