﻿using Newtonsoft.Json;
using Programowanie3Projekt.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Programowanie3Projekt
{
    /// <summary>
    /// Interaction logic for Orders.xaml
    /// </summary>
    public partial class Orders : Window
    {
        HttpClient client = new HttpClient();

        public Orders()
        {
            client.BaseAddress = new Uri("http://localhost:5090/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
                );
            InitializeComponent();
        }

        private void btnLoadWarehouse_Click(object sender, RoutedEventArgs e)
        {
            this.GetClientOrders();
        }

        private async void GetClientOrders()
        {
            lblMessage.Content = "";
            var response = await client.GetStringAsync("warehouse/clientorders");
            var clientOrders = JsonConvert.DeserializeObject<List<ClientOrders>>(response);
            dataGridWarehouse.DataContext = clientOrders;
        }

        private void btnSaveGood_Click(object sender, RoutedEventArgs e)
        {
            var clientOrders = new ClientOrders()
            {
                ID = Convert.ToInt32(txtId.Text),
                OrdererName = txtOrdererName.Text,
                OrdererSurename = txtOrdererSurename.Text,
                OrderCity = txtOrderCity.Text,
                OrderedAmount = Convert.ToInt32(txtOrderedAmount.Text)
            };

            if (clientOrders.ID == 0)
            {
                this.SaveClientOrders(clientOrders);
                lblMessage.Content = "Dodano wpis do magazynu";
            }
            else
            {
                this.UpdateClientOrders(clientOrders);
                lblMessage.Content = "Zaktualizowano spis magazynu";
            }

            txtId.Text = 0.ToString();
            txtOrdererName.Text = "";
            txtOrdererSurename.Text = "";
            txtOrderCity.Text = "";
            txtOrderedAmount.Text = 0.ToString();


        }

        void btnEditGood(object sender, RoutedEventArgs e)
        {
            ClientOrders clientOrders = ((FrameworkElement)sender).DataContext as ClientOrders;
            txtId.Text = clientOrders.ID.ToString();
            txtOrdererName.Text = clientOrders.OrdererName;
            txtOrdererSurename.Text = clientOrders.OrdererSurename;
            txtOrderCity.Text = clientOrders.OrderCity;
            txtOrderedAmount.Text = clientOrders.OrderedAmount.ToString();
        }

        private async void SaveClientOrders(ClientOrders clientOrders)
        {
            await client.PostAsJsonAsync("warehouse/clientorders", clientOrders);
        }

        private async void UpdateClientOrders(ClientOrders clientOrders)
        {
            var result = await client.PutAsJsonAsync("warehouse/clientorders/" + clientOrders.ID, clientOrders);
        }
    }
}
