﻿using Newtonsoft.Json;
using Programowanie3Projekt.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Programowanie3Projekt
{
    /// <summary>
    /// Interaction logic for AddOrder.xaml
    /// </summary>
    public partial class AddOrder : Window
    {
        HttpClient client = new HttpClient();

        public AddOrder()
        {
            client.BaseAddress = new Uri("http://localhost:5090/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")
                );
            InitializeComponent();
        }

        private void btnLoadWarehouse_Click(object sender, RoutedEventArgs e)
        {
            this.GetConnectedTables();
        }

        private async void GetConnectedTables()
        {
            lblMessage.Content = "";
            var response = await client.GetStringAsync("warehouse/tables");
            var connectedTables = JsonConvert.DeserializeObject<List<ConnectedTables>>(response);
            dataGridWarehouse.DataContext = connectedTables;
        }

        private void btnSaveGood_Click(object sender, RoutedEventArgs e)
        {
            var warehouseData = new Warehouse()
            {
                ID = Convert.ToInt32(txtId.Text),
                WareName = txtWareName.Text,
                SerialNumber = Convert.ToInt32(txtSerialNumber.Text),
                LetterPosition = txtLetterPosition.Text,
                NumberPosition = Convert.ToInt32(txtNumberPosition.Text),
                DockerName = txtDockerName.Text,
                DockerSurename = txtDockerSurename.Text,
            };

            // Dla tabeli ClientOrders
            var clientOrdersData = new ClientOrders()
            {
                ID = Convert.ToInt32(txtId.Text),
                OrdererName = txtOrdererName.Text,
                OrdererSurename = txtOrdererSurename.Text,
                OrderCity = txtOrderCity.Text,
                OrderedAmount = Convert.ToInt32(txtOrderedAmount.Text),
            };

            if (warehouseData.ID == 0)
            {
                this.SaveWarehouse(warehouseData);
                lblMessage.Content = "Dodano wpis do magazynu";
            }
            else
            {
                this.UpdateWarehouse(warehouseData);
                lblMessage.Content = "Zaktualizowano spis magazynu";
            }

            if (clientOrdersData.ID == 0)
            {
                this.SaveClientOrders(clientOrdersData);
                lblMessage.Content += "\nDodano wpis do zamówień";
            }
            else
            {
                this.UpdateClientOrders(clientOrdersData);
                lblMessage.Content += "\nZaktualizowano spis zamówień";
            }

            txtId.Text = 0.ToString();
            txtWareName.Text = "";
            txtSerialNumber.Text = 0.ToString();
            txtLetterPosition.Text = "";
            txtNumberPosition.Text = 0.ToString();
            txtDockerName.Text = "";
            txtDockerSurename.Text = "";
            txtOrdererName.Text = "";
            txtOrdererSurename.Text = "";
            txtOrderCity.Text = "";
            txtOrderedAmount.Text = 0.ToString();


        }

        private async void SaveWarehouse(Warehouse warehouseData)
        {
            await client.PostAsJsonAsync("warehouse/warehouse", warehouseData);
        }

        private async void UpdateWarehouse(Warehouse warehouseData)
        {
            await client.PutAsJsonAsync("warehouse/warehouse/" + warehouseData.ID, warehouseData);
        }

        private async void SaveClientOrders(ClientOrders clientOrdersData)
        {
            await client.PostAsJsonAsync("warehouse/clientorders", clientOrdersData);
        }

        private async void UpdateClientOrders(ClientOrders clientOrdersData)
        {
            await client.PutAsJsonAsync("warehouse/clientorders/" + clientOrdersData.ID, clientOrdersData);
        }
    }
}
